This repository simply compiles different versions of VerbNet over time.

If anybody can send me a VerbNet version that is not here, I'd be glad to add
it. (I'm looking for 3.0, 1.2 -> 1.4, confirmations about 2.1 and 2.2, and any
subversions (eg. 3.2.2).)

See LICENSE.md for licensing.
